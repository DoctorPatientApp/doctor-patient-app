import React from "react";

const PatientDashboard=()=>{
    return(
<>
      <div className="patient-dashboard mt-4 ">
        <div className="row">
          <div className="col-lg-12">
            <h3>Patient Dashboard</h3>
          </div>
        </div>
      </div>
    </>
    )
}
export default PatientDashboard